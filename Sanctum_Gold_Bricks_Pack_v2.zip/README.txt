This pack contains Ready-to-Push JSON bricks.
Folders:
  app/       -> mechanics, vault, rules
  altar/     -> rituals, altar interactions
  familiars/ -> familiar & Char content
  lore/      -> quests & narrative
  grief/     -> shadow work & grief

Unzip into your ~/Spineforge folder.
